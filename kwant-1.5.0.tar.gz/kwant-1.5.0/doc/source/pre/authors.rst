.. include:: ../../../AUTHORS.rst
