.. include:: ../../../LICENSE.rst
